// Enregistrement d'un fichier produit par la page (exports, clé de chiffrement). Navigateur : lien <a download>.
// Application Android (android/) : la WebView ignore les liens blob: ; le fichier passe au pont LezardApp, qui
// demande à la personne où l'enregistrer.
export async function saveBlob(blob, name) {
  if (window.LezardApp?.saveFile) {
    const data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",", 2)[1] || "");
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
    window.LezardApp.saveFile(name, blob.type || "application/octet-stream", data);
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement("a"), { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

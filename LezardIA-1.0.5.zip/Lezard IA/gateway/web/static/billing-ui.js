// Panneau « Abonnement » (7.1) : souscription via Stripe Checkout, gestion via le portail client.
import { api, errorMessage } from "./auth.js";

const $ = (id) => document.getElementById(id);
const STATUS = {
  active: ["Actif", ""], trialing: ["Période d'essai", ""],
  past_due: ["Paiement en retard — mettez à jour votre moyen de paiement pour conserver le plan", "warn"],
  unpaid: ["Impayé — plan suspendu", "crit"], canceled: ["Résilié", ""], incomplete: ["Paiement à finaliser", "warn"],
  incomplete_expired: ["Paiement expiré", "crit"], paused: ["En pause", "warn"],
};

function message(text, kind = "info") {
  const m = $("bl-msg");
  m.textContent = text;
  m.className = `alert${text ? " show" : ""}${kind === "ok" ? " ok-box" : ""}`;
}

async function go(path, button) {
  button.disabled = true;
  const r = await api(path, { method: "POST", body: {} });
  button.disabled = false;
  if (!r.ok) return message(errorMessage(r));
  location.assign(r.data.url);                      // page Stripe (Checkout ou portail)
}

function render(b) {
  $("bl-plan").textContent = b.plan === "pro" ? "Pro" : "Free";
  const sub = b.subscription;
  const [label, level] = sub ? (STATUS[sub.status] || [sub.status, ""]) : ["Aucun abonnement", ""];
  $("bl-status").textContent = label;
  $("bl-status").className = `billing-status ${level}`;
  let detail = "";
  if (sub?.current_period_end && sub.status !== "canceled") {
    const d = new Date(sub.current_period_end * 1000).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
    detail = sub.cancel_at_period_end ? `Se termine le ${d} (résiliation programmée).` : `Se renouvelle le ${d}.`;
  }
  $("bl-detail").textContent = detail;
  $("bl-portal").hidden = !b.has_customer;
  current = b;
  Object.keys(OPTS).forEach((name) => renderOption(name, b));
}

// ---------- options Pro (7.3) et Hébergement cloud (7.4) ----------
const fmtDate = (ts) => new Date(ts * 1000).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
const OPTS = {
  pro: { the: "l'option Pro", on: "Active — multi-agents débloqué.", after: "puis retour au plan Free",
         added: "Option Pro activée : l'orchestration multi-agents est disponible dans le chat.",
         lost: "Le multi-agents est désactivé tout de suite" },
  hosted: { the: "l'option Hébergement cloud", on: "Active — gateway hébergée 24/7, ponts autorisés.",
            after: "puis fin de l'accès hébergé",
            added: "Hébergement cloud activé : créez un pont pour relier vos modèles locaux.",
            lost: "L'accès à la gateway hébergée et les ponts sont coupés tout de suite" },
};
let current = null;
const cap = (s) => s[0].toUpperCase() + s.slice(1);

function renderOption(name, b) {
  const o = b[name] || {}, viaConfig = name === "pro" && b.effective_plan === "pro" && !o.active;
  // l'hébergement n'a de sens que sur l'instance managée (ou s'il est déjà souscrit)
  const relevant = name !== "hosted" || b.instance === "managed" || o.active;
  $(`${name}-card`).hidden = !relevant || (!o.available && !o.active);
  $(`${name}-card`).classList.toggle("on", o.active || viaConfig);
  $(`${name}-price`).textContent = `${eur(o.price_eur ?? 0).replace(",00", "")} / mois`;
  const state = $(`${name}-state`);
  let text = "", cls = "pro-state";
  if (viaConfig) [text, cls] = ["Inclus dans votre compte (configuration de l'instance).", "pro-state on"];
  else if (o.ending) [text, cls] = [`Active jusqu'au ${fmtDate(b.subscription.current_period_end)}, ${OPTS[name].after}.`, "pro-state warn"];
  else if (o.active) [text, cls] = [OPTS[name].on, "pro-state on"];
  state.textContent = text;
  state.className = cls;
  $(`${name}-add`).hidden = viaConfig || (o.active && !o.ending);
  $(`${name}-add`).textContent = `${o.ending ? "Conserver" : "Activer"} ${OPTS[name].the}`;
  $(`${name}-remove`).hidden = !o.active || o.ending;
}

async function addOption(name, button) {
  if (current?.subscribed && !current[name]?.ending &&
      !confirm(`${cap(OPTS[name].the)} sera ajoutée à votre abonnement : le montant au prorata du mois en cours est prélevé immédiatement. Continuer ?`)) return;
  button.disabled = true;
  const r = await api(`/v1/billing/${name}`, { method: "POST", body: {} });
  button.disabled = false;
  if (!r.ok) return message(errorMessage(r));
  if (r.data.url) return location.assign(r.data.url);             // pas encore abonné : Stripe Checkout
  message(r.data.action === "resumed" ? `Résiliation annulée : ${OPTS[name].the} continue.` : OPTS[name].added, "ok");
  loadBilling();
  document.dispatchEvent(new CustomEvent("billing:changed"));
}

async function removeOption(name, button) {
  const others = (current?.subscription?.items || []).length > 1;
  if (!confirm(others
    ? `Retirer ${OPTS[name].the} maintenant ? ${OPTS[name].lost} et la part non consommée du mois est créditée sur votre prochaine facture.`
    : `Résilier ${OPTS[name].the} ? Elle reste active jusqu'à la fin de la période déjà payée.`)) return;
  button.disabled = true;
  const r = await api(`/v1/billing/${name}`, { method: "DELETE" });
  button.disabled = false;
  if (!r.ok) return message(errorMessage(r));
  message(r.data.action === "ending" ? `${cap(OPTS[name].the)} est résiliée : active jusqu'au ${fmtDate(r.data.ends_at)}.`
    : `${cap(OPTS[name].the)} est retirée.`, "ok");
  loadBilling();
  document.dispatchEvent(new CustomEvent("billing:changed"));
}


const eur = (v) => `${v.toFixed(2).replace(".", ",")} €`;

function el(tag, text) { const e = document.createElement(tag); e.textContent = text; return e; }

async function loadPrice() {
  const r = await api("/v1/billing/price");
  if (!r.ok) return;
  const p = r.data;
  $("pr-ais").textContent = p.connected
    ? `${p.connected} IA connectée${p.connected > 1 ? "s" : ""} ce mois-ci : ${p.providers.join(", ")}` +
      (p.enforced && !p.auto_billed ? " — 1 incluse ; ajoutez-en via un abonnement." : "")
    : "Aucune IA utilisée ce mois-ci : la première est offerte.";
  const body = $("pr-lines");
  body.replaceChildren();
  for (const l of p.lines) {
    const tr = document.createElement("tr");
    tr.append(el("th", l.quantity > 1 ? `${l.label} × ${l.quantity}` : l.label), el("td", l.total_eur ? eur(l.total_eur) : "offert"));
    tr.firstChild.scope = "row";
    body.append(tr);
  }
  $("pr-total").textContent = `${eur(p.total_eur)} / mois`;
}

async function simulate() {
  const n = $("sim-n").value;
  $("sim-n-out").textContent = n;
  const q = new URLSearchParams({ connected: n, pro: $("sim-pro").checked, hosted: $("sim-hosted").checked });
  const r = await api(`/v1/billing/price/simulate?${q}`);
  if (!r.ok) return;
  $("sim-total").textContent = `${eur(r.data.total_eur)} / mois`;
  const fmt = (o, v) => `${eur(current?.[o]?.price_eur ?? v).replace(",00", "")}/mois`;
  $("sim-formula").textContent = `${r.data.formula} — Pro ${fmt("pro", 3)} — hébergement managé ${fmt("hosted", 5)}.`;
}

export async function loadBilling() {
  const r = await api("/v1/billing");
  if (!r.ok || !r.data.enabled) return false;
  $("billing-section").hidden = false;
  render(r.data);
  loadPrice();
  return r.data;
}

export async function initBilling() {
  for (const name of Object.keys(OPTS)) {
    $(`${name}-add`).addEventListener("click", (e) => addOption(name, e.currentTarget));
    $(`${name}-remove`).addEventListener("click", (e) => removeOption(name, e.currentTarget));
  }
  $("bl-portal").addEventListener("click", (e) => go("/v1/billing/portal", e.currentTarget));
  ["sim-n", "sim-pro", "sim-hosted"].forEach((id) => $(id).addEventListener("input", simulate));
  simulate();
  const params = new URLSearchParams(location.search);
  const back = params.get("billing"), wants = OPTS[params.get("upgrade")] ? params.get("upgrade") : null;
  if (back || wants) history.replaceState(null, "", location.pathname);   // nettoie l'URL (retour Stripe, lien du chat)
  const state = await loadBilling();
  if (!state) return;
  if (wants) {               // arrivée depuis la puce « Multi-agents » du chat ou le panneau des ponts
    $(`${wants}-card`).scrollIntoView({ block: "center" });
    if (!$(`${wants}-add`).hidden) $(`${wants}-add`).focus();
  }
  if (back === "cancel") message("Paiement annulé : aucun montant n'a été prélevé.");
  if (back === "success") {
    message("Paiement reçu, activation de votre abonnement…", "ok");
    // le webhook Stripe peut arriver quelques secondes après la redirection
    for (let i = 0; i < 10; i++) {
      await new Promise((ok) => setTimeout(ok, 1500));
      const s = await loadBilling();
      if (s?.subscribed) {          // Pro ou IA supplémentaires seules (plan « extras »)
        message(s.plan === "pro" ? "Abonnement Pro actif : multi-agents débloqué. Merci !" : "Abonnement actif. Merci !", "ok");
        document.dispatchEvent(new CustomEvent("billing:changed"));
        return;
      }
    }
    message("Paiement reçu. L'activation prend plus de temps que prévu : rechargez la page dans un instant.");
  }
}
